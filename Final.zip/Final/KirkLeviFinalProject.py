from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font

class BZ(EasyFrame):

    def __init__(self):

        # these variables are choices of what the user wants in their order
        # setting all variables to false
        self.soft = False
        self.sugar = False
        self.waffle = False
        self.vanilla = False
        self.chocolate = False
        self.strawberry = False
        self.sprinkles = False
        self.fudge = False
        self.caramel = False

        # Window Creation and Image creation
        EasyFrame.__init__(self, title = "BelowZero")
        imageLabel = self.addLabel(text="", row=1, column=1,
                                   sticky="NSEW")
        textLabel = self.addLabel(text="", row=2, column=1, sticky="NSEW")

        self.image = PhotoImage(file="cone.gif")
        imageLabel["image"] = self.image

        font = Font(family="Verdana", size=15, slant="italic")
        textLabel["font"] = font
        textLabel["foreground"] = "blue"

        #Greeting
        self.label = self.addLabel(text = "Welcome! What kind of cone would you like? You can also get soft serve.",
                      row = 0,
                      column = 1,
                      sticky = "NSEW")

        # All Buttons
        self.LeftButton = self.addButton(text = "Soft Serve", row = 3, column = 0, command = self.LeftCommand)

        self.MiddleButton = self.addButton(text="Sugar Cone", row=3, column=1, command=self.MiddleCommand)

        self.RightButton = self.addButton(text="Waffle Cone", row=3, column=2, command=self.RightCommand)

        self.BackButton = self.addButton(text="Back", row = 4, column = 0, command = self.BackCommand)

        self.ExitButton = self.addButton(text = "Exit", row = 4, column = 2, command = self.ExitCommand)

        self.placeOrder = self.addButton(text="Place Order", row=4, column=1,
                                         command=self.orderButton, state="disabled")




    # Commands

    def LeftCommand(self):
        self.label["text"] = "What kind of ice cream would you like?"
        #Change text of buttons
        self.LeftButton["text"] = "Vanilla"
        self.MiddleButton["text"] = "Chocolate"
        self.RightButton["text"] = "Strawberry"
        self.soft = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand2
        self.RightButton["command"] = self.RightCommand2
        self.MiddleButton["command"] = self.MiddleCommand2
        self.image["file"] = "icecream.gif"


    def MiddleCommand(self):
        self.label["text"] = "What kind of ice cream would you like?"
        # Change text of buttons
        self.LeftButton["text"] = "Vanilla"
        self.MiddleButton["text"] = "Chocolate"
        self.RightButton["text"] = "Strawberry"
        self.sugar = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand2
        self.MiddleButton["command"] = self.MiddleCommand2
        self.RightButton["command"] = self.RightCommand2
        self.image["file"] = "icecream.gif"

    def RightCommand(self):
        self.label["text"] = "What kind of ice cream would you like?"
        # Change text of buttons
        self.LeftButton["text"] = "Vanilla"
        self.MiddleButton["text"] = "Chocolate"
        self.RightButton["text"] = "Strawberry"
        self.waffle = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand2
        self.RightButton["command"] = self.RightCommand2
        self.MiddleButton["command"] = self.MiddleCommand2
        self.image["file"] = "icecream.gif"


    def LeftCommand2(self):
        self.label["text"] = "What kind of topping would you like?"
        # Change text of buttons
        self.LeftButton["text"] = "Sprinkles"
        self.MiddleButton["text"] = "Hot Fudge"
        self.RightButton["text"] = "Caramel"
        self.vanilla = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand3
        self.RightButton["command"] = self.RightCommand3
        self.MiddleButton["command"] = self.MiddleCommand3
        self.BackButton["command"] = self.BackCommand2
        self.image["file"] = "toppings.gif"


    def MiddleCommand2(self):
        self.label["text"] = "What kind of topping would you like?"
        # Change text of buttons
        self.LeftButton["text"] = "Sprinkles"
        self.MiddleButton["text"] = "Hot Fudge"
        self.RightButton["text"] = "Caramel"
        self.chocolate = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand3
        self.RightButton["command"] = self.RightCommand3
        self.MiddleButton["command"] = self.MiddleCommand3
        self.BackButton["command"] = self.BackCommand2
        self.image["file"] = "toppings.gif"

    def RightCommand2(self):
        self.label["text"] = "What kind of topping would you like?"
        # Change text of buttons
        self.LeftButton["text"] = "Sprinkles"
        self.MiddleButton["text"] = "Hot Fudge"
        self.RightButton["text"] = "Caramel"
        self.strawberry = True # if this button is selected, set this variable to True
        self.LeftButton["command"] = self.LeftCommand3
        self.RightButton["command"] = self.RightCommand3
        self.MiddleButton["command"] = self.MiddleCommand3
        self.BackButton["command"] = self.BackCommand2
        self.image["file"] = "toppings.gif"

    def LeftCommand3(self):
        self.label["text"] = "Please place your order, or push the back button to change your choices."
        # Disable buttons
        self.LeftButton["state"] = "disabled"
        self.MiddleButton["state"] = "disabled"
        self.RightButton["state"] = "disabled"
        self.sprinkles = True # if this button is selected, set this variable to True
        self.placeOrder["state"] = "normal"
        self.BackButton["command"] = self.BackCommand3


    def MiddleCommand3(self):
        self.label["text"] = "Please place your order, or push the back button to change your choices."
        # Disable buttons
        self.LeftButton["state"] = "disabled"
        self.MiddleButton["state"] = "disabled"
        self.RightButton["state"] = "disabled"
        self.fudge = True # if this button is selected, set this variable to True
        self.placeOrder["state"] = "normal"
        self.BackButton["command"] = self.BackCommand3


    def RightCommand3(self):
        self.label["text"] = "Please place your order, or push the back button to change your choices."
        # Disable buttons
        self.LeftButton["state"] = "disabled"
        self.MiddleButton["state"] = "disabled"
        self.RightButton["state"] = "disabled"
        self.caramel = True # if this button is selected, set this variable to True
        self.placeOrder["state"] = "normal"
        self.BackButton["command"] = self.BackCommand3

    # Back Commands
    def BackCommand(self):
        self.label["text"] = "Welcome! What kind of cone would you like? You can also get soft serve."
        self.soft, self.sugar, self.waffle = False, False, False # Go back, reset variables to false
        self.LeftButton["text"] = "Soft Serve"
        self.MiddleButton["text"] = "Sugar Cone"
        self.RightButton["text"] = "Waffle Cone"
        self.LeftButton["command"] = self.LeftCommand
        self.RightButton["command"] = self.RightCommand
        self.MiddleButton["command"] = self.MiddleCommand
        self.image["file"] = "cone.gif"

    def BackCommand2(self):
        self.vanilla, self.chocolate, self.strawberry = False, False, False # Go back, reset variables to false
        self.label["text"] = "What kind of ice cream would you like?"
        self.LeftButton["text"] = "Vanilla"
        self.MiddleButton["text"] = "Chocolate"
        self.RightButton["text"] = "Strawberry"
        self.LeftButton["command"] = self.LeftCommand2
        self.RightButton["command"] = self.RightCommand2
        self.MiddleButton["command"] = self.MiddleCommand2
        self.BackButton["command"] = self.BackCommand
        self.image["file"] = "icecream.gif"


    def BackCommand3(self):
        self.sprinkles, self.fudge, self.caramel = False, False, False # Go back, reset variables to false
        self.label["text"] = "What kind of topping would you like?"
        self.LeftButton["state"] = "normal"
        self.MiddleButton["state"] = "normal"
        self.RightButton["state"] = "normal"
        self.LeftButton["text"] = "Sprinkles"
        self.MiddleButton["text"] = "Hot Fudge"
        self.RightButton["text"] = "Caramel"
        self.LeftButton["command"] = self.LeftCommand3
        self.RightButton["command"] = self.RightCommand3
        self.MiddleButton["command"] = self.MiddleCommand3
        self.BackButton["command"] = self.BackCommand2
        self.placeOrder["state"] = "disabled"
        self.image["file"] = "toppings.gif"

    #Exit Command
    def ExitCommand(self):
        self.master.destroy()

    #Order Command
    def orderButton(self):

        #Creating the entire order for the message box at the end
        message = ""
        if self.soft == True:
            message = message + "Soft Serve "
        if self.sugar == True:
            message = message + "Sugar Cone "
        if self.waffle == True:
            message = message + "Waffle Cone "
        if self.vanilla == True:
            message = message + "with vanilla ice cream "
        if self.chocolate == True:
            message = message + "with chocolate ice cream "
        if self.strawberry == True:
            message = message + "with strawberry ice cream "
        if self.sprinkles == True:
            message = message + "and sprinkles."
        if self.fudge == True:
            message = message + "and hot fudge."
        if self.caramel == True:
            message = message + "and caramel."

        self.messageBox(title = "Order: ", message = "Thank you for your order of a " + message)

        # Now return back to main menu for next customer, reset everything
        self.label["text"] = "Welcome! What kind of cone would you like? You can also get soft serve."
        self.soft = False
        self.sugar = False
        self.waffle = False
        self.vanilla = False
        self.chocolate = False
        self.strawberry = False
        self.sprinkles = False
        self.fudge = False
        self.caramel = False
        self.LeftButton["state"] = "normal"
        self.MiddleButton["state"] = "normal"
        self.RightButton["state"] = "normal"
        self.LeftButton["text"] = "Soft Serve"
        self.MiddleButton["text"] = "Sugar Cone"
        self.RightButton["text"] = "Waffle Cone"
        self.LeftButton["command"] = self.LeftCommand
        self.RightButton["command"] = self.RightCommand
        self.MiddleButton["command"] = self.MiddleCommand
        self.placeOrder["state"] = "disabled"
        self.image["file"] = "cone.gif"


#to run the window
def main():
    BZ().mainloop()

if __name__ == "__main__":
    main()